var glob = require("glob")

var viewports = [
    {
      "label": "PC",
      "width": 1600,
      "height": 1200
    }
];

var hideSelectors = [];
var removeSelectors = [];
var selectors = [];
var scenariosArray = [];

// 확인이 필요한 프로젝트 경로
var htmlFiles = glob.sync("../GROUPWARE/connect3/src/pc/AlphaN/*.html");

htmlFiles.forEach(function(file, i) {
file.substring();
  var filename = file;
  filename = filename.substring(3);

  scenariosArray.push({
    "label": filename,
    "url": "http://127.0.0.1/" + filename,
    "hideSelectors": hideSelectors,
    "removeSelectors": removeSelectors,
    "selectors": selectors,
    "delay": 500
  });
});

module.exports = {
  "id": "css-regression-testing",
  "viewports": viewports,
  "scenarios": scenariosArray,
  "paths": {
    "bitmaps_reference": "backstop_data/bitmaps_reference",
    "bitmaps_test": "backstop_data/bitmaps_test",
    "casper_scripts": "backstop_data/casper_scripts",
    "html_report": "backstop_data/html_report",
    "ci_report": "backstop_data/ci_report"
  },
  "casperFlags": [],
  "engine": "phantomjs",
  "report": ["browser"],
  "debug": false
}
