'use strict';

const gulp              = require('gulp');
const backstopjs        = require('backstopjs');

var backstopConfig = {
  config: './backstopConfig.js'
}

gulp.task('backstop_reference', () => backstopjs('reference', backstopConfig));
gulp.task('backstop_test', () => backstopjs('test', backstopConfig));
